var express = require('express');
var nodemailer = require('nodemailer');
var hbs = require('express-handlebars');

var app = express();

app.use(express.static('public'));
app.use(express.urlencoded({extended: true}));

app.engine('handlebars', hbs());
app.set('view engine', 'handlebars');

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'orlando.brea@gmail.com',
        pass: 'jkhsdkjhdsasad'
    }
});

app.get('/', function(req, res) {
    res.send('Pagina <strong>principal</strong>');
})

// http://localhost/hola?nombre=Orlando
app.get('/hola', function(req, res) {
    //res.send('Bienvenido '+req.query.nombre);
    res.send(`Bienvenido, ${req.query.nombre}`);
});

// http://localhost/hola/Orlando
app.get('/hola/:nombre', function(req, res) {
    res.send('Bienvenido '+req.params.nombre);
});


app.post('/contacto', async function(req, res) {

    var opciones = {
        from: 'orlando.brea@gmail.com',
        to: 'orlando.brea@gmail.com',
        subject: 'Titulo del email',
        text: 'Cuerpo del email'
    }
    await transporter.sendMail(opciones);
    res.send(req.body.nombre);
    
    //console.log(req.body);
    
});

app.get('/acerca-de', function(req, res) {
    res.render('acerca', {titulo: 'Mi titulo!'});
});

app.listen(80, function() {
    console.log('App escuchando en el puerto 80');
});
